import pymongo
import os
import time
import sys
import random
import threading
from colorama import init, Fore, Style

init(autoreset=True)

try:
    client = pymongo.MongoClient("mongodb://localhost:27017/")
    db = client["bu_canteen"]
    menu = db["menu"]
    orders = db["orders"]
    emps = db["employees"]
except Exception as e:
    print(Fore.RED + f"DB Err: {e}")
    sys.exit()

cart = []
tot = 0
current_view = "menu"
last_state = ""

def clr():
    os.system('cls' if os.name == 'nt' else 'clear')

def tp(text, color=Fore.WHITE, speed=0.01):
    for char in text:
        sys.stdout.write(color + char)
        sys.stdout.flush()
        time.sleep(speed)
    print()

def banner():
    clr()
    print(Fore.CYAN + Style.BRIGHT + "=" * 50)
    print(Fore.CYAN + Style.BRIGHT + " " * 15 + "BU CANTEEN")
    print(Fore.CYAN + Style.BRIGHT + "=" * 50)
    
    prep = list(orders.find({"status": "Preparing"}))
    ready = list(orders.find({"status": "Ready"}))
    
    print(Fore.YELLOW + Style.BRIGHT + "\n[ LIVE TRACKING ]")
    p_str = ", ".join([f"#{p['order_id']}" for p in prep]) if prep else "None"
    r_str = ", ".join([f"#{r['order_id']}" for r in ready]) if ready else "None"
    
    print(Fore.YELLOW + f"  🔥 PREPARING: {p_str}")
    print(Fore.GREEN + f"  ✅ READY: {r_str}")
    print(Fore.CYAN + "=" * 50 + "\n")

def draw_menu(prompt=False):
    banner()
    items = list(menu.find({"in_stock": True}))
    for i, itm in enumerate(items, 1):
        print(Fore.YELLOW + f"[{i}] {itm['name'].ljust(30)} ₹{itm['price']}")
    print(Fore.MAGENTA + "-" * 50)
    print(Fore.GREEN + f"CART TOTAL: ₹{tot} | ITEMS: {len(cart)}")
    print(Fore.MAGENTA + "-" * 50)
    print(Fore.WHITE + "[0] Checkout / Pay Bill")
    if prompt:
        sys.stdout.write(Fore.WHITE + "\nSelect: ")
        sys.stdout.flush()

def draw_admin(prompt=False):
    banner()
    print(Fore.RED + Style.BRIGHT + "DASHBOARD")
    print(Fore.YELLOW + "[1] Receive Cash (Unpaid -> Preparing)")
    print(Fore.YELLOW + "[2] Send to Counter (Preparing -> Ready)")
    print(Fore.YELLOW + "[3] Clear Delivered Orders (Ready -> Done)")
    print(Fore.YELLOW + "[4] Add Menu Item")
    print(Fore.YELLOW + "[5] Change Item Price")
    print(Fore.YELLOW + "[6] Toggle Item Stock")
    print(Fore.YELLOW + "[7] Logout")
    if prompt:
        sys.stdout.write(Fore.WHITE + "\nAction: ")
        sys.stdout.flush()

def live_updater():
    global last_state
    while True:
        time.sleep(1.5)
        curr_orders = list(orders.find({}, {"_id": 0, "order_id": 1, "status": 1}))
        state_str = str(curr_orders)
        
        if state_str != last_state:
            last_state = state_str
            if current_view == "menu":
                draw_menu(True)
            elif current_view == "admin":
                draw_admin(True)

def admin_panel():
    global current_view
    current_view = "busy"
    banner()
    tp("Secure Portal", Fore.RED)
    u = input(Fore.WHITE + "User: ")
    p = input(Fore.WHITE + "Pass: ")
    
    if not emps.find_one({"username": u, "password": p}):
        tp("Auth Failed.", Fore.RED)
        time.sleep(1)
        current_view = "menu"
        return

    while True:
        current_view = "admin"
        draw_admin()
        c = input(Fore.WHITE + "\nAction: ")
        current_view = "busy"
        
        if c == '1':
            unpaid = list(orders.find({"status": "Unpaid"}))
            if not unpaid:
                tp("No unpaid bills.", Fore.GREEN)
                time.sleep(1)
                continue
            for u_ord in unpaid:
                print(Fore.CYAN + f"#{u_ord['order_id']} | ₹{u_ord['total']} | {', '.join(u_ord['items'])}")
            oid = input(Fore.WHITE + "Enter Order ID to mark PAID: ")
            if oid.isdigit():
                orders.update_one({"order_id": int(oid)}, {"$set": {"status": "Preparing"}})
                tp("Payment received. Kitchen notified.", Fore.GREEN)
                time.sleep(1)

        elif c == '2':
            prep = list(orders.find({"status": "Preparing"}))
            if not prep:
                tp("Nothing in kitchen.", Fore.GREEN)
                time.sleep(1)
                continue
            for p_ord in prep:
                print(Fore.CYAN + f"#{p_ord['order_id']} | {', '.join(p_ord['items'])}")
            oid = input(Fore.WHITE + "Enter Order ID to mark READY: ")
            if oid.isdigit():
                orders.update_one({"order_id": int(oid)}, {"$set": {"status": "Ready"}})
                tp("Announced on board.", Fore.GREEN)
                time.sleep(1)

        elif c == '3':
            ready = list(orders.find({"status": "Ready"}))
            if not ready:
                tp("Counter clear.", Fore.GREEN)
                time.sleep(1)
                continue
            for r_ord in ready:
                print(Fore.CYAN + f"#{r_ord['order_id']} | ₹{r_ord['total']}")
            oid = input(Fore.WHITE + "Enter Order ID delivered: ")
            if oid.isdigit():
                orders.update_one({"order_id": int(oid)}, {"$set": {"status": "Completed"}})
                tp("Order archived.", Fore.GREEN)
                time.sleep(1)

        elif c == '4':
            n = input("Name: ")
            p_price = int(input("Price: "))
            cat = input("Category: ")
            menu.insert_one({"name": n, "price": p_price, "in_stock": True, "category": cat})
            tp("Added.", Fore.GREEN)
            time.sleep(1)

        elif c == '5':
            items = list(menu.find())
            for i, itm in enumerate(items, 1):
                print(f"[{i}] {itm['name']} - ₹{itm['price']}")
            s = int(input("Item number: "))
            if s > 0:
                np = int(input("New price: ₹"))
                menu.update_one({"_id": items[s-1]["_id"]}, {"$set": {"price": np}})
                tp("Price updated.", Fore.GREEN)
                time.sleep(1)

        elif c == '6':
            items = list(menu.find())
            for i, itm in enumerate(items, 1):
                st = Fore.GREEN + "IN" if itm['in_stock'] else Fore.RED + "OUT"
                print(f"[{i}] {itm['name']} [{st}]")
            s = int(input("Item number: "))
            if s > 0:
                menu.update_one({"_id": items[s-1]["_id"]}, {"$set": {"in_stock": not items[s-1]['in_stock']}})
                tp("Stock updated.", Fore.GREEN)
                time.sleep(1)

        elif c == '7':
            current_view = "menu"
            break

def main():
    global cart, tot, current_view
    
    threading.Thread(target=live_updater, daemon=True).start()
    
    while True:
        current_view = "menu"
        draw_menu()
        
        c = input(Fore.WHITE + "\nSelect: ").strip()
        current_view = "busy"
        
        if c == '1000':
            admin_panel()
        elif c == '999':
            tp("Terminating...", Fore.RED)
            break
        elif c == '0':
            if not cart:
                tp("Cart is empty.", Fore.RED)
                time.sleep(1)
                continue
                
            oid = random.randint(1000, 9999)
            orders.insert_one({
                "order_id": oid,
                "items": [x['name'] for x in cart],
                "total": tot,
                "status": "Unpaid"
            })
            
            banner()
            tp("GENERATING BILL...", Fore.CYAN)
            print(Fore.WHITE + "=" * 40)
            print(Fore.GREEN + Style.BRIGHT + f"  TOKEN ID: #{oid}")
            print(Fore.WHITE + "=" * 40)
            for x in cart:
                print(f"  - {x['name'].ljust(25)} ₹{x['price']}")
            print(Fore.WHITE + "-" * 40)
            print(Fore.YELLOW + Style.BRIGHT + f"  AMOUNT PAYABLE: ₹{tot}")
            print(Fore.WHITE + "=" * 40)
            tp("\nPlease pay cash at the counter to start preparation.", Fore.RED)
            input(Fore.WHITE + "\nPress Enter to clear screen...")
            
            cart.clear()
            tot = 0
            
        elif c.isdigit():
            items = list(menu.find({"in_stock": True}))
            if 1 <= int(c) <= len(items):
                sel = items[int(c)-1]
                cart.append(sel)
                tot += sel['price']
                tp(f"+ {sel['name']}", Fore.GREEN, speed=0.005)
                time.sleep(0.3)
            else:
                tp("Invalid.", Fore.RED, speed=0.005)
                time.sleep(0.5)

if __name__ == "__main__":
    main()